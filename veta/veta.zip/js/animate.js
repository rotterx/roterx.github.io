$(document).ready(function() {
	
	$('.beta').addClass('animated fadeInUp');
	$('.digital').addClass('animated rotateInUpLeft');
	
}); 